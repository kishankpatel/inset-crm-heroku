This Wakeupsales Self-Hosted CRM Bundle comes with the v4.0 source code.

Any updates later will have to be downloaded manually from our website. Or you can get in touch with us on "support@wakeupsales.com".

You can setup the Wakeupsales CRM on Windows, Mac or Linux environment. 


Cheers!